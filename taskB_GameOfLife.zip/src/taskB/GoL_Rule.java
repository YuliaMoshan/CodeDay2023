package taskB;


/**
 * 
 * @author 
 * This class implements the CA rule for a standard 'Game of Life' simulation
 *
 */
public class GoL_Rule implements CA_Rule
{
	// TODO add code as appropriate.

	@Override
	public void ImplementRule()
	{
		// TODO Auto-generated method stub

	}

}
