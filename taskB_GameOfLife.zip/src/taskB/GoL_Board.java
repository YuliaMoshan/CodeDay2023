package taskB;

import java.util.Iterator;

/**
 * 
 * @author 
 * This class implements a Game of life board
 * 
 */
public class GoL_Board extends CA
{
	/**
	 * 
	 * @param rows: Number of rows
	 * @param cols: Number of columns
	 * Init new GoL automaton with an empty board
	 */
	public GoL_Board(int rows, int cols)
	{
		// TODO Auto-generated constructor stub
	}

	@Override
	public Iterator iterator()
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * 
	 * @param board: The board to be set.
	 * Set parameter board as current board
	 */
	public void SetBoard(int[][] board)
	{
		// TODO Auto-generated method stub
	}

	/**
	 * 
	 * @return current CA state as a String 
	 */
	public String CurrentBoardOutput()
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	// TODO add methods and fields as needed.
	
}
