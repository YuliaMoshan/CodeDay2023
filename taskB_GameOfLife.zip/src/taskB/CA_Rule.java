package taskB;

/**
 * 
 * @author 
 * Interface for
 */
public interface CA_Rule
{
	// TODO add code as appropriate.
	abstract public void ImplementRule();
}
